# Load Packages
library(tidyverse)
library(clusterProfiler)
library(org.Hs.eg.db)
library(ReactomePA)

#Load data 

data<- read.csv("control_deg_B.csv")

data$Gene_Symbol<-as.factor(data$Gene_Symbol)
data$GeneID<-as.factor(data$GeneID)
data$ENTREZ_GENE_ID<-as.factor(data$ENTREZ_GENE_ID)

glimpse(data)

#Identify overexpressed genes

overexpressed_gene<-data |> 
  filter(padj<0.05 & log2FoldChange>3)

#Load data 

overexpressed<-overexpressed_gene |> 
  dplyr::select(Gene_Symbol,ENTREZ_GENE_ID)

#Gene ontology
GO_BP <- enrichGO(overexpressed$ENTREZ_GENE_ID,
                  OrgDb = "org.Hs.eg.db",
                  ont = "BP",
                  pvalueCutoff = 0.05,
                  pAdjustMethod = "BH")
dotplot(GO_BP)


# KEGG Enrichment

kegg <- enrichKEGG(gene =overexpressed$ENTREZ_GENE_ID,
                   organism = "hsa",
                   pvalueCutoff = 0.05)

dotplot(kegg)


# Wikipathway

WIKI <- enrichWP(gene = overexpressed$ENTREZ_GENE_ID,
                 organism = "Homo sapiens")
dotplot(WIKI)

# Reactome

Reactome <- enrichPathway(overexpressed$ENTREZ_GENE_ID,
                          organism = "human",
                          pvalueCutoff = 0.05,
                          pAdjustMethod = "BH")
dotplot(Reactome)


