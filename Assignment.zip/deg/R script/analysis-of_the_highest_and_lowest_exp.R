#Load packages
library(tidyverse)
library(skimr)
library(openxlsx)
library(readxl)
library(dplyr) 
library(ggplot2)
# Load data 

control<-read.csv("control_groups.csv")
ms<-read.csv("Ms_groups.csv")

#Higher and underexpression of genes
Underexpressed_control_gene<- control|> 
  filter(adjPVal<  0.05 & logFC<2) |> 
     head(100)

ggplot(data = Underexpressed_control_gene, aes(x = Gene_Symbol,y=AveExpr, fill = logFC )) +
    geom_col() +
    theme_minimal() 
  +   labs(title = "Underexpressed Genes", 
           x = "Gene symbol", y = "Average Expression", 
           fill = "Log Fold Change")

overexpressed_controlled_gene<- control |> 
  filter(adjPVal<0.05 & logFC>15) |> 
  head(100)

ggplot(data = overexpressed_controlled_gene, aes(x=Gene_Symbol,y= AveExpr,fill = logFC))+
  geom_col()+
  theme_gray() 
+   labs(title = "Overexpressed Genes", 
         x = "Gene symbol", y = "Average Expression", 
         fill = "Log Fold Change")

#  significant  genes of controlled group

significant<-bind_rows(overexpressed_controlled_gene,Underexpressed_control_gene)
write.csv(significant,"significant_control.csv", row.names = FALSE)
write.csv(Underexpressed_control_gene,"underexpressed_control.csv",row.names = FALSE)
write.csv(overexpressed_controlled_gene,"overexpressed_control.csv", row.names = FALSE)

underexpressed_ms<- ms |> 
  filter(adjPVal<0.05 & logFC<2) |> 
  head(100)
ggplot(data = underexpressed_ms, aes(x=Gene_Symbol,y= AveExpr,fill = logFC))+
  geom_col()+
  theme_gray() 
+   labs(title = "Underxpressed Genes", 
         x = "Gene symbol", y = "Average Expression", 
         fill = "Log Fold Change")

overexpressed_ms<- ms |> 
  filter(adjPVal<0.05 & logFC>15) |> 
  head(100)

ggplot(data = overexpressed_ms, aes(x=Gene_Symbol,y= AveExpr,fill = logFC))+
  geom_col()+
  theme_gray() 
+   labs(title = "Overexpressed Genes", 
         x = "Gene symbol", y = "Average Expression", 
         fill = "Log Fold Change")

#Significat genes of ms groups
significant<-bind_rows(overexpressed_ms,underexpressed_ms)
write.csv(significant, "signifant_ms_genes.csv",row.names = FALSE)
write.csv(underexpressed_ms,"underexpressed_ms.csv", row.names = FALSE)
write.csv(overexpressed_ms, "overexpressed_ms.csv", row.names = FALSE)
