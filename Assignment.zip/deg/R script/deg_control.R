# Load necessary libraries
library(DESeq2)
library(ggplot2)
library(dplyr)
library(pheatmap)
library(ggrepel)

# Load dataset
data <- read.csv("control_groups.csv", stringsAsFactors = FALSE)
data<-select(data, -c(1,18, 19))
write.csv(data, "control_groups_ent.csv", row.names = FALSE)


# Load the data
data <- read.csv("control_groups_ent.csv", header = TRUE, row.names = 1)

# Check the structure of the data
str(data)

# Extract the count data (columns starting with "GSM")
count_data <- data |> select(starts_with("GSM"))

# Convert the count data to a matrix (DESeq2 requires a matrix)
count_matrix <- as.matrix(count_data)
count_matrix <- round(count_matrix)
# Check for missing values and handle them (e.g., replace with 0)
count_matrix[is.na(count_matrix)] <- 0

# Check for duplicate columns and remove them if necessary
count_matrix <- count_matrix[, !duplicated(colnames(count_matrix))]

# Create a sample information data frame (assuming all samples are from the "MS" group)
sample_info <- data.frame(condition = rep("Control", ncol(count_matrix)))
rownames(sample_info) <- colnames(count_matrix)

# Create the DESeqDataSet object
dds <- DESeqDataSetFromMatrix(countData = count_matrix,
                              colData = sample_info,
                              design = ~ 1)

# Pre-filtering: remove rows with very low counts
dds <- dds[rowSums(counts(dds)) > 10, ]
# Run DESeq2
dds <- DESeq(dds)

# Get the results
res <- results(dds)

# Summarize the results
summary(res)

head(res)

write.csv(res, "control_deg_A.csv")


#Load data

Control_groups<-read.csv("control_groups.csv")
Control_groups<-select(Control_groups, -c(1, 3:18, 21:26))
res<-read.csv("control_deg_A.csv")
control_deg_A<-merge(res, Control_groups, by= "GeneID", all=TRUE )

write.csv(control_deg_A, "control_deg_B.csv")
