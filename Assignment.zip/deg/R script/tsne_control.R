#Install packages
install.packages("Rtsne")


library(tidyverse)
library(skimr)
library(openxlsx)
library(readxl)
library(dplyr) 
library(ggplot2)
library(naniar)
library(Rtsne)


# Read the data
data <- read.csv("significant_control.csv")

# Remove rows with missing values
data <- na.omit(data)

# Extract the gene expression data (columns starting with "GSM")
expression_data <- data %>% select(starts_with("GSM"))

# Perform t-SNE
set.seed(123)  # For reproducibility
tsne_result <- Rtsne(expression_data, perplexity = 20, check_duplicates = FALSE)

# Create a data frame for plotting
tsne_df <- data.frame(tsne_result$Y)
colnames(tsne_df) <- c("tSNE1", "tSNE2")

# Add Gene_Symbol to the t-SNE data frame for coloring
tsne_df$Gene_Symbol <- data$Gene_Symbol

# Plot the t-SNE results
ggplot(tsne_df, aes(x = tSNE1, y = tSNE2, color = Gene_Symbol)) +
  geom_point(size = 2) +
  theme_minimal() +
  labs(title = "t-SNE Plot of Gene Expression in Control Patients",
       x = "t-SNE Dimension 1",
       y = "t-SNE Dimension 2",
       color= "Gene Symbol"
       )