#Load packages 
library(tidyverse)
library(tidyverse)
library(naniar)
library(readxl)
library(openxlsx)
library(limma)
library(ggplot2)
library(ggpubr)
library(sjPlot)
#Load data 
phenotype_data<-read.csv("phenotype_data.csv")
expression_data<-read.csv("expression_data.csv")

# Gene expression analysis

design <- model.matrix(~0 + phenotype_data$disease_.state_ch1)
fit <- lmFit(expression_data, design)
fit <- eBayes(fit)
All_genes <- topTable(fit, coef = 1, number = Inf)

write.csv(All_genes, "All_genes.csv", row.names = FALSE)



# Merging the gene expression data

feature_data<- read.csv("feature_data.csv")

feature_d<-select(feature_data, -c(2,3,5,6,7,8,9))
All_gene<- read.csv("All_genes.csv")

merging_data<- merge(feature_d,  All_genes, by= "GeneID", all=TRUE)
merging_data

write.csv(merging_data, "All_gene_expression.csv", row.names = FALSE)

#Filtering out the low expressed genes
 Underexpressed_control_gene<- control|> 
  +   filter(adjPVal<= 0.05 & logFC<5) |> 
  +   head(20)
      
 ggplot(data = Underexpressed_control_gene, aes(x = Gene_Symbol, y=AveExpr, fill = logFC)) +
  +   geom_bar() +
  +   theme_minimal() +
  +   labs(title = "Underexpressed Genes", 
           x = "Gene symbol", y = "Average Expression", 
           fill = "Log Fold Change")