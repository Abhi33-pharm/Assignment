#Install and update packages

update.packages(ask = FALSE, checkBuilt = TRUE)
install.packages("tzdb")
BiocManager::install("GEOquery", force = TRUE)
library(tzdb)
library(GEOquery)
library(openxlsx)
library(tidyverse)
library(knitr)
opts_chunk$set(warning=FALSE,message=FALSE,cache=FALSE)
library(limma)
#Data download and import

#gse<-getGEO("")
gse <- getGEO("GSE21942", GSEMatrix = TRUE)

#Inspect the data

str(gse)

#Access expression data

expression_data <- exprs(gse[[1]])

#Access the pheonotype data 

phenotype_data <- pData(gse[[1]])

#Access feature data

feature_data <- fData(gse[[1]])

#Normalize the data
expression_data<-log2(expression_data+1)


# Export the data 
 write.csv(expression_data,"expression_data.csv")
write.csv(phenotype_data,"phenotype_data.csv", row.names = FALSE)
write.csv(feature_data, "feature_data.csv", row.names = FALSE)

