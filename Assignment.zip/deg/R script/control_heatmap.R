#Load Packages
library(tidyverse)
library(ggpubr)
library(sjPlot)
library(ggthemes)
library(hrbrthemes)
library(RColorBrewer)
library(viridis)
library(paletteer)
library(ggsci)
library(naniar)
#Install packages
library(pheatmap)
library(colorRamp2)
# Load necessary libraries
library(dplyr)
library(pheatmap)

# Load necessary libraries
library(pheatmap)
library(dplyr)

# Read the data
# Load necessary libraries
library(pheatmap)
library(dplyr)

# Read the data
data <- read.csv("significant_control.csv")

# Remove rows with missing values
data <- na.omit(data)
 


#We can aggregate the duplicate gene symbols by taking the mean of their expressions
data_cleaned <- data %>%
  group_by(Gene_Symbol) %>%
  summarise(across(starts_with("GSM"), mean, na.rm = TRUE)) |> 
  as.data.frame()
 
# Set the Gene_Symbol as row names
rownames(data_cleaned) <- data_cleaned$Gene_Symbol
data_cleaned <- data_cleaned[, -1] 


data_matrix <- as.matrix(data_cleaned)

dist_matrix <- dist(data_matrix, method = "euclidean")
hc <- hclust(dist_matrix, method = "complete")
plot(hc)  # Check if clustering works

# Create the heatmap
pheatmap(dist_matrix, 
        scale = "row",
         clustering_distance_rows = "euclidean",   
         clustering_distance_cols = "euclidean",   
        clustering_method = "complete",  
         show_rownames = TRUE,   
         show_colnames = TRUE)
 