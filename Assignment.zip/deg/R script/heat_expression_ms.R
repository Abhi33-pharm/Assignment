library(tidyverse)
library(ggpubr)
library(sjPlot)
library(ggthemes)
library(hrbrthemes)
library(RColorBrewer)
library(viridis)
library(paletteer)
library(ggsci)
library(naniar)
#Install packages
install.packages("pheatmap")
library(pheatmap)
install.packages("colorRamp2")
library(colorRamp2)
# Load necessary libraries
library(dplyr)
library(pheatmap)
# Load necessary libraries
library(pheatmap)
library(dplyr)

# Read the data
data <- read.csv("signifant_ms_genes.csv")

# Remove rows with missing values
data <- na.omit(data)

#We can aggregate the duplicate gene symbols by taking the mean of their expressions
data_cleaned <- data %>%
  group_by(Gene_Symbol) %>%
  summarise(across(starts_with("GSM"), mean, na.rm = TRUE)) |> 
  as.data.frame()

# Set the Gene_Symbol as row names
rownames(data_cleaned) <- data_cleaned$Gene_Symbol
data_cleaned <- data_cleaned[, -1]   
# Create the heatmap
pheatmap(data_cleaned, 
         scale = "row",   
         clustering_distance_rows = "euclidean",   
         clustering_distance_cols = "euclidean",   
         clustering_method = "complete",  
         show_rownames = TRUE,   
         show_colnames = TRUE)   

