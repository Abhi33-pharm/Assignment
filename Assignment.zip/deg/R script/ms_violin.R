# data manipulation
library(tidyverse)

# advanced visualization
library(ggpubr)
library(sjPlot)

# themes
library(ggthemes)
library(hrbrthemes)

# colors
library(RColorBrewer)
library(viridis)
library(paletteer)
library(ggsci)

#Load data

data<-read.csv("Ms_groups.csv")

#Convert logFold to log2fold
data<- data |> 
  mutate(log2fold_change = logFC / log(2)) 

data$GeneID<-as.factor(data$GeneID)
data$Gene_Title<-as.factor(data$Gene_Title)
data$Gene_Symbol<-as.factor(data$Gene_Symbol)
data$ENTREZ_GENE_ID<-as.factor(data$ENTREZ_GENE_ID)

# Significantly expressed gene

overexpressed_genes<-data |> 
  filter(adjPVal<0.05 & log2fold_change>15)

underexpressed_genes<- data |> 
  filter(adjPVal<0.05 & log2fold_change<10)

significant_gene<-bind_rows(overexpressed_genes, underexpressed_genes)

#Create a violin plot

# Add a column to the data frame to specify if they are UP- or DOWN- regulated (log2fc respectively positive or negative)<br /><br /><br />
significant_gene$diffexpressed <- "NO"

# if log2Foldchange > 15 and pvalue < 0.05, set as "UP"<

significant_gene$diffexpressed[significant_gene$log2fold_change > 15 & significant_gene$PValue < 0.05] <- "UP"

# if log2Foldchange < -10 and pvalue < 0.05, set as "down"

significant_gene$diffexpressed[significant_gene$log2fold_change < -10 & significant_gene$PValue < 0.05] <- "DOWN"

# Order by fold change to get the most highly expressed
sig_up_ordered <- significant_gene[order(-significant_gene$log2fold_change), ]

# Get the top 10 most highly expressed genes
top10_up <- head(sig_up_ordered, 10)

# Print the gene names and fold changes
top10_up[, c("Gene_Symbol", "log2fold_change")]

# For publication, you might want:
cat("The most highly expressed genes were:", 
    paste(rownames(top10_up), collapse=", "), 
    "with fold changes ranging from", 
    round(min(top10_up$log2FoldChange), 2), 
    "to", 
    round(max(top10_up$log2FoldChange), 2))





# Order by fold change (most negative first)
sig_down_ordered <- significant_gene[order(significant_gene$log2fold_change), ]

# Get top 10 most downregulated genes
top10_down <- head(sig_down_ordered, 10)

# View results
top10_down[, c("Gene_Symbol", "log2fold_change")]

 

# Print the gene names and fold changes
top10_up[, c("Gene_Symbol", "log2fold_change")]

write.csv (top10_up,"ms_top_10.csv", row.names = FALSE)
write.csv(top10_down,"ms_down_10", row.names = FALSE)


# Explore a bit

head(significant_gene[order(significant_gene$adjPVal) & significant_gene$diffexpressed == 'DOWN', ])


ggplot(top10_up, aes(x=Gene_Symbol, y=log2fold_change, fill ="olivedrab"  ))+geom_col()+theme_bw()

ggplot(top10_down, aes(x=Gene_Symbol, y=log2fold_change, fill ="olivedrab"  ))+geom_col()+theme_bw()





ggplot(significant_gene, aes(x = log2fold_change, y = log10(PValue), fill = diffexpressed)) +
  geom_violin(trim = FALSE) +
  theme_minimal() +geom_boxplot()
labs(title = "Gene Expression in Ms Patients")



