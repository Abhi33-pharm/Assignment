# Load packages
library(tidyverse)
library(readxl)
library(openxlsx)
library(limma)


#Load data
Expression_data<- read.csv("expression_data.csv")
All_genes<-read.csv("All_genes.csv")
All_genes_expression<-read.csv("All_gene_expression.csv")

#Removing column 
All_genes_expression<-select(All_genes_expression, -c(2,6,7,8,9))
Control_groups<-select(Expression_data, c(1:16))
Ms_groups<-select(Expression_data, c(1,17:30))

#Merge data
Control_groups<-merge(Control_groups, All_genes_expression, by="GeneID", all = TRUE)
Ms_groups<-merge(Ms_groups, All_genes_expression, by="GeneID", all=TRUE)

write.csv(Control_groups, "control_groups.csv")
write.csv(Ms_groups, "Ms_groups.csv")

