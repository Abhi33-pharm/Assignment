
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("DESeq2")

library(tidyverse)
library(pheatmap)
library(ggplot2)
library(DESeq2)
library(ggpubr)
library(tibble)
library(readr)


# Load the dataset

data<- read.csv("All_expression_data.csv")

# Remove rows with any missing values in expression data columns
expression_cols <- 2:29  # Excluding metadata columns
data_cleaned <- data |>  drop_na(all_of(expression_cols))

# Remove duplicate gene entries based on GeneID
data_cleaned <- data_cleaned |>  distinct(GeneID, .keep_all = TRUE)

# Save the cleaned dataset
write.csv(data_cleaned, "Cleaned_expression_data.csv", row.names = FALSE)

# Display summary
print(dim(data_cleaned))  # Check dimensions
head(data_cleaned)         # Preview first few rows 


# Load the cleaned data
data <- read.csv("Cleaned_expression_data.csv", row.names = 1)
# Extract sample names (first 29 columns are samples)
samples <- colnames(data)[1:29]

# Round expression values to nearest integers (required for DESeq2)
data[, samples] <- round(data[, samples])

# Define conditions
condition <- c(rep("Control", 15), rep("MS", 14))

# Create colData (metadata)
colData <- data.frame(condition = factor(condition))
rownames(colData) <- samples

# Create DESeq2 dataset
dds <- DESeqDataSetFromMatrix(countData = as.matrix(data[, samples]), colData = colData, design = ~ condition)

# Run DESeq2
dds <- DESeq(dds)

# Extract results
res <- results(dds, alpha = 0.05) 
res <- res[order(res$padj), ]  
head(res)

# Save results
write.csv(res, "DEGs_results.csv")

 

# Load DEGs results file
deg_data <- read.csv("DEGs_results.csv")

# Ensure column names are correct
colnames(deg_data)

# Filter DEGs: adjPVal < 0.05 and log2FC > 1 or < -1
filtered_DEGs <- deg_data |> 
  filter(pvalue< 0.05 & abs(log2FoldChange) > 1)

# Save the filtered DEGs
write.csv(filtered_DEGs, "Filtered_DEGs.csv", row.names = FALSE)

# Display top results
head(filtered_DEGs)

write.csv(filtered_DEGs, "filtered.csv", row.names = FALSE)


 